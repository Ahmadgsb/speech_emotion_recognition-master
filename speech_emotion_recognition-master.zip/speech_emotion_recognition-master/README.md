# speech_emotion_recognition

In this project, the performance of speech emotion recognition is compared between two methods.Conventional classifiers that uses machine learning algorithms has been used for decades in recognizing emotions from speech. However, in recent years, deep
learning methods have taken the center stage and have gained popularity for their ability to perform well without
any input hand-crafted features. Speech emotion on sets obtained from RAVDESS corpus is classified using a conventionally used Support Vector Machine (SVM) and its performance is compared to that of a bidirectional long short-term memory (LSTM).
